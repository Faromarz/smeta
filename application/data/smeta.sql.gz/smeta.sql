-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Июн 27 2014 г., 13:04
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `smeta`
--

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id`, `name`, `description`) VALUES
(1, 'login', 'Login privileges, granted after account confirmation'),
(2, 'admin', ''),
(3, 'partner', '');

-- --------------------------------------------------------

--
-- Структура таблицы `roles_users`
--

CREATE TABLE IF NOT EXISTS `roles_users` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `fk_role_id` (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `roles_users`
--

INSERT INTO `roles_users` (`user_id`, `role_id`) VALUES
(1, 1),
(1, 2),
(2, 1),
(2, 3),
(4, 2),
(4, 3),
(5, 2),
(5, 3),
(6, 1),
(6, 3),
(7, 1),
(7, 3),
(8, 1),
(8, 3),
(9, 1),
(9, 3),
(10, 1),
(10, 3),
(12, 1),
(12, 3),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(254) NOT NULL,
  `phone` varchar(64) DEFAULT NULL,
  `username` varchar(32) NOT NULL DEFAULT '',
  `password` varchar(64) NOT NULL,
  `logins` int(10) unsigned NOT NULL DEFAULT '0',
  `last_login` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_username` (`username`),
  UNIQUE KEY `uniq_email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `email`, `phone`, `username`, `password`, `logins`, `last_login`) VALUES
(1, 'sozidanirf@gmail.com', ' 7(777)777-77-77', 'admin', '4acb48e213c0da1c1fe474b994ffc8a0cf44f883d342063f93185e5a054f50e3', 551, 1403685797),
(2, 'partner@admin.com', ' 7(777)777-77-77', 'partner', '44fc4ab241727bac375dc627683d08aea177c5d372b2fa84fb679208c1b72a83', 5, 1385143121),
(4, 'partner2@admin.com', ' 7(777)777-77-77', 'partner2', '44fc4ab241727bac375dc627683d08aea177c5d372b2fa84fb679208c1b72a83', 0, NULL),
(5, 'partner3@admin.com', ' 7(777)777-77-77', 'partner3', '44fc4ab241727bac375dc627683d08aea177c5d372b2fa84fb679208c1b72a83', 0, NULL),
(6, 'skmiara@gmail.com', ' 7(777)777-74-95', 'skmiara', '753982d0b9d8d9900212437e40a8ef36f01e71f3bf974a7a4c618f8861aa30ee', 16, 1390857188),
(7, '7201798@mail.ru', ' 7(777)495-72-01', '7201798', 'e0563ac503a26c7fc2a21ec190ef2d50cc4ca480b952fe293e5fd9f6013471b1', 14, 1389466914),
(8, 'triera_info@mail.ru', ' 7(777)792-51-93', 'triera_info', 'fc1929939cfe09cbf091ba14ded609114c17c68e3fdba5f43d7b903da77d19b8', 12, 1395763043),
(9, 'tank3@inbox.ru', ' 7(749)576-85-56', 'tank3', '39e4e33052cbfee027b833fc45d15ba0c45dc1a3cfa7c1a495d54e0b0bd51400', 5, 1390465832),
(10, 'ymremont@gmail.com', ' 7(781)298-27-03', 'ymremont', '3901aa0e2638be785affe816e08c8f05a0ace816210bc60a94604a2d88800478', 5, 1390041222),
(12, 'ooostoik@gmail.com', ' 7(906)785-68-02', 'ooostoik', 'edcc2f8fe1794a0d9c6005700f5438f7928f0f35f5a4a84b328cfae8ccc5b05a', 2, 1390421282),
(24, 'sozidanierf@gmail.com', NULL, '36506535339522310', '32da2e7bc32e29be652861d8684fc2a212d0c09cb4911ab796a80a09f3ad7b41', 1, 1390862128),
(25, 'Altair-mankind@yandex.ru', NULL, '64423980519927552', '6aead2bb4fcd44f31651ab25e5786e8e4241e26bb6845173612d8de4481398c5', 1, 1390862800),
(32, 'senj@mail.ru', NULL, '43131382441489949', 'ec7859e86fe725d542d45af10a8a4ff9f1697d518967df64d0cf99bf135199e5', 1, 1390864733),
(33, 'VAVILON@NM.RU', NULL, '07384575861850557', '789096687cb139a1735ced37c6712c055370b3cbc43ab7a4461c25594cd9b4ea', 1, 1390997767),
(34, 'morgan.mihail@yandex.ru', NULL, '78980061952440012', '586da0389c47ea9397d33b344001a15f5e3bf14fa6f25ae92b60e4dc393b572d', 1, 1391054166),
(35, 'sabonvitalii@yandex.ru', NULL, '72052205615836957', 'bbe433e0a0e62466639d24ab2ec33c607b3e3528d9525e79f94c6a332fcae69f', 1, 1391093200),
(36, 'ustim111@yandex.ru', NULL, '31186382643425208', '42d54f728871cf84515d5ae146730b212612092cd563daeb01fafe44a8478b7f', 1, 1391633981),
(37, 'davydovvy@rambler.ru', NULL, '82221049671828442', '84916c2e2b3cfa827d106db5efe334b88482b86fc1d1d14a807aa0dd0768f250', 2, 1392574926),
(38, 'gazarian@gmail.com', NULL, '17402202179791865', 'af5958faef3b15090d6cd3d3fbb2318adb4ab445a1d854983247a82825e7354b', 2, 1393101365);

-- --------------------------------------------------------

--
-- Структура таблицы `user_tokens`
--

CREATE TABLE IF NOT EXISTS `user_tokens` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `user_agent` varchar(40) NOT NULL,
  `token` varchar(40) NOT NULL,
  `type` varchar(100) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `expires` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_token` (`token`),
  KEY `fk_user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
